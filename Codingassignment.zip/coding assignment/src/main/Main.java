package main;

import java.util.Scanner;

import dao.ProductService1;
import dao.ProductService2;
import entity.Product;
import entity.User;
import exception.OrderNotFoundException;
import exception.ProductNotFoundException;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("============ Order Management System ============");

        ProductService1 productService = new ProductService1(scanner);
        ProductService2 userService = new ProductService2(scanner);

        while (true) {
        	System.out.println("Welcome to Order Management System");
            System.out.println("\nChoose an option:");
            System.out.println("1. Create User");
            System.out.println("2. Create Product");
            System.out.println("3. Get All Products");
            System.out.println("4. Get Orders by User");
            System.out.println("5. Cancel Order");
            System.out.println("6. Exit");
            System.out.println("=====================================================");


            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    createUser(userService);
                    break;
                case 2:
                    createProduct(productService);
                    break;
                case 3:
                    getAllProducts(productService);
                    break;
                case 4:
                    getOrdersByUser(userService);
                    break;
                case 5:
                    deleteProduct(productService);
                    break;
                
                case 6:
                    System.out.println("Exiting...");
                    System.out.println("Thank you for using the Order Management System!");
                    System.out.println("============ End of Order Management System ============");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    
	private static void createUser(ProductService2 userService) {
        System.out.println("\nEnter User ID:");
        int userId = scanner.nextInt();
        scanner.nextLine();  // Consume the newline character
        System.out.println("Enter User Name:");
        String userName = scanner.nextLine();
        System.out.println("Enter Password:");
        String password = scanner.nextLine();

        User newUser = new User(userId, userName, password, "User");
        if (userService.createUser(newUser)) {
            System.out.println("User created successfully.");
        } else {
            System.out.println("User ID already exists. Enter a new User ID.");
        }
    }

    private static void createProduct(ProductService1 productService) {
        System.out.println("\nEnter Product ID:");
        int productId = scanner.nextInt();
        scanner.nextLine();  // Consume the newline character
        System.out.println("Enter Product Name:");
        String productName = scanner.nextLine();
        System.out.println("Enter Description:");
        String description = scanner.nextLine();
        System.out.println("Enter Price:");
        double price = scanner.nextDouble();
        System.out.println("Enter Quantity in Stock:");
        int quantityInStock = scanner.nextInt();
        scanner.nextLine();  // Consume the newline character
        System.out.println("Enter Type:");
        String type = scanner.nextLine();

        Product newProduct = new Product(productId, productName, description, (int) price, quantityInStock, type);
        if (productService.createProduct(newProduct)) {
            System.out.println("Product created successfully.");
        } else {
            System.out.println("Product ID already exists. Enter a new Product ID.");
        }
    }

    private static void getAllProducts(ProductService1 productService) {
        System.out.println("\nAll Products:");
        productService.getAllProducts().forEach(System.out::println);
    }

    private static void getOrdersByUser(ProductService2 userService) {
        System.out.println("Enter User ID to get orders:");
        int userId = scanner.nextInt();

        Iterable<Product> orderedProducts = userService.getOrdersByUser(userId);
        if (orderedProducts != null) {
            System.out.println("Products ordered by user:");
            orderedProducts.forEach(System.out::println);
        } else {
            System.out.println("No orders found for the specified user.");
        }
    }
    private static void cancelOrder(ProductService2 productService) {
            System.out.println("Enter User ID to cancel order:");
            int userId = scanner.nextInt();
            System.out.println("Enter Order ID to cancel:");
            int orderId = scanner.nextInt();
            try {
            boolean canceled = productService.cancelOrder(userId, orderId);

            if (canceled) {
                System.out.println("Order canceled successfully.");
            } else {
                System.out.println("Order not found or cancellation failed.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("An unexpected error occurred.");
        }
    }
    private static void deleteProduct(ProductService1 productService) {
        System.out.println("Enter Product ID to delete:");
        int productId = scanner.nextInt();

        if (productService.deleteProduct(productId)) {
            System.out.println("Product deleted successfully.");
        } else {
            System.out.println("Product not found or deletion failed. Enter a valid Product ID.");
        }
    }



}
