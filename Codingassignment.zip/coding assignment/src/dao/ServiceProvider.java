package dao;

import java.sql.SQLException;
import java.util.List;

import entity.Clothing;
import entity.Electronics;
import entity.Order;
import entity.Product;
import entity.User;

public interface ServiceProvider
{
    // Product related methods
    void addProduct(Product product);
    Product getProductById(int productId);
    List<Product> getAllProducts();
    boolean updateProduct(Product product);
    boolean deleteProduct(int productId);

    // Electronics related methods
    void addElectronics(Electronics electronics);
    Electronics getElectronicsById(int productId);
    List<Electronics> getAllElectronics();
    void updateElectronics(Electronics electronics);
    void deleteElectronics(int productId);

    // Clothing related methods
    void addClothing(Clothing clothing);
    Clothing getClothingById(int productId);
    List<Clothing> getAllClothing();
    void updateClothing(Clothing clothing);
    void deleteClothing(int productId);

    // User related methods
    void addUser(User user);
    User getUserById(int userId);
    List<User> getAllUsers();
    boolean updateUser(User user);
    boolean deleteUser(int userId) throws SQLException;

    // Order related methods
    void addOrder(Order order);
    void getOrderById(User user);
    List<Order> getAllOrders();
    void updateOrder(Order order);
    boolean deleteOrder(int orderId);
	Iterable<Product> getOrderByUser(User user);
	boolean productExists(int productId);
	boolean userExists(int userId);
	boolean createUser(User User);
	User getUser(int UserId);
	java.util.Collection<User> getAllUser();
	boolean createProduct(Product product);
	Product getProduct(int productId);
	boolean cancelOrder(int userId, int orderId);
	Iterable<Product> getOrdersByUser1(int userId);
	Iterable<Product> getOrdersByUser(int userId);
	boolean cancelOrder1(int userId, int orderId);
}

