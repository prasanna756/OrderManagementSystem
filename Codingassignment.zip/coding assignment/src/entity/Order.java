package entity;

import java.util.Date;
import java.util.List;

public class Order {
    private int orderId;
    private Date orderDate;
    private int userId;
    private List<Product> products;

    public Order(int orderId, int userId, List<Product> products) {
        this.orderId = orderId;
        this.orderDate = new Date(); // Current date/time
        this.userId = userId;
        this.products = products;
    }

    public int getOrderId() {
        return orderId;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public int getUserId() {
        return userId;
    }

    public List<Product> getProducts() {
        return products;
    }
}
